package com.cholitoburitto.simplyequine.client.entity.render;

import com.cholitoburitto.simplyequine.client.entity.model.MareThoroughbredEntityModel;
import com.cholitoburitto.simplyequine.entities.MareThoroughbredEntity;
import com.cholitoburitto.simplyequine.simply_equine;
import com.google.common.collect.Maps;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.AbstractHorseRenderer;
import net.minecraft.client.renderer.entity.EntityRendererManager;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.layers.LeatherHorseArmorLayer;
import net.minecraft.client.renderer.entity.model.HorseModel;
import net.minecraft.client.renderer.texture.LayeredTexture;
import net.minecraft.entity.passive.horse.HorseEntity;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

import javax.annotation.Nullable;
import java.util.Map;

public class MareThoroughbredEntityRender extends MobRenderer<MareThoroughbredEntity, MareThoroughbredEntityModel> {

    protected static final ResourceLocation THOROUGHBRED_BLACK = new ResourceLocation(simply_equine.MOD_ID,
            "textures/entity/thoroughbred_black.png");
    protected static final ResourceLocation THOROUGHBRED_BROWN = new ResourceLocation(simply_equine.MOD_ID,
            "textures/entity/thoroughbred_brown.png");
    protected static final ResourceLocation THOROUGHBRED_GRAY = new ResourceLocation(simply_equine.MOD_ID,
            "textures/entity/thoroughbred_gray.png");
    protected static final ResourceLocation THOROUGHBRED_CHESTNUT = new ResourceLocation(simply_equine.MOD_ID,
            "textures/entity/thoroughbred_chestnut.png");
    protected static final ResourceLocation THOROUGHBRED_REDCHESTNUT = new ResourceLocation(simply_equine.MOD_ID,
            "textures/entity/thoroughbred_redchestnut.png");
    protected static final ResourceLocation THOROUGHBRED_WHITE = new ResourceLocation(simply_equine.MOD_ID,
            "textures/entity/thoroughbred_white.png");

    public MareThoroughbredEntityRender(EntityRendererManager renderManagerIn) {
        super(renderManagerIn, new MareThoroughbredEntityModel(), 0.5f);
    }

    @Override
    public ResourceLocation getEntityTexture(MareThoroughbredEntity entity) {
        switch (entity.getTextureType()) {
            default:
            case 0:
                return THOROUGHBRED_BLACK;
            case 1:
                return THOROUGHBRED_BROWN;
            case 2:
                return THOROUGHBRED_GRAY;
            case 3:
                return THOROUGHBRED_CHESTNUT;
            case 4:
                return THOROUGHBRED_REDCHESTNUT;
            case 5:
                return THOROUGHBRED_WHITE;
        }
    }
}