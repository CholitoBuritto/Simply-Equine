package util;

import net.minecraftforge.registries.ObjectHolder;
@ObjectHolder("shavingsblock")
public class ShavingsBlockLayers {

}
