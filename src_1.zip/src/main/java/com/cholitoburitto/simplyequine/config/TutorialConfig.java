package com.cholitoburitto.simplyequine.config;

public final class TutorialConfig {
    public static boolean enablePowderLayers;
}
