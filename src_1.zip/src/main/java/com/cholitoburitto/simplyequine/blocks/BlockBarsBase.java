package com.cholitoburitto.simplyequine.blocks;

import net.minecraft.block.PaneBlock;

public class BlockBarsBase extends PaneBlock{
    public BlockBarsBase(Properties properties) {
        super(properties.notSolid());
        }
}
