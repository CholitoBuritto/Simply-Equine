package com.cholitoburitto.simplyequine.blocks.doors;

import net.minecraft.block.DoorBlock;


public class OakStallDoor extends DoorBlock {

    public OakStallDoor(Properties builder) {
        super(builder);
    }
}