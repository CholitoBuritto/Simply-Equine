package com.cholitoburitto.simplyequine.config;

public final class SimplyEquineConfig {
    public static boolean enableLayers;
}
