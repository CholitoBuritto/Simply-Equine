package com.cholitoburitto.simplyequine.items;


import com.cholitoburitto.simplyequine.simply_equine;
import net.minecraft.item.Item;

public class ItemBase extends Item {
    public ItemBase() {
        super(new Item.Properties().group(simply_equine.EQUINE_ITEMS));
    }
}
